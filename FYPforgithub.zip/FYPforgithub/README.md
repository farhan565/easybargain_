# easybargain_

Clone the repository in VS Code.
Change the branch to "Complete".

# Running Backend
Go to the directory backend/ebid in terminal of VS code and write command "npm install".
After that, write command "npm start".
Server will start running.

# Running Frontend
Go to the directory /easybargain in terminal of VS code and write command "npm install".
After that, write command "npm start".
React App will start running and loading in the browser.
